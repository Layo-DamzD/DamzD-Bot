import { menuText, helpText } from "./menus.js";
import { uptimeText } from "./utils.js";

// Commands return plain action objects — bot.js does the sending: an optional
// picture FIRST, then the text as ONE unbroken message. Pure and testable.
//
// owner: true → only the owner (his own account) can run it.

export function createCommands({ config, runtime }) {
  const commands = [
    {
      name: "menu",
      aliases: ["mn"],
      owner: false,
      description: "the info card — picture first, then everything",
      run: () => ({
        image: true,
        text: menuText(config, {
          mode: runtime.mode,
          autoReply: runtime.autoReply,
          delayMinutes: Math.round(runtime.delayMs() / 60000)
        })
      })
    },
    {
      name: "help",
      aliases: ["commands", "guide"],
      owner: false,
      description: "how I work, every command explained",
      run: () => ({ image: true, text: helpText(config) })
    },
    {
      name: "ping",
      owner: false,
      description: "check that I am alive",
      run: () => ({
        text:
          "⚡ *" + config.botName + "* is online\n" +
          "⏱ Uptime: " + uptimeText(runtime.startedAt) + "\n" +
          "🔐 Mode: " + runtime.mode + "\n" +
          "🤖 Auto-reply: " + (runtime.autoReply ? "on" : "off") + "\n" +
          "⏰ My time: " + config.timezone
      })
    },
    {
      name: "autoreply",
      aliases: ["autoreplies"],
      owner: true,
      description: "turn the 5-minute answers on or off",
      run: ctx => {
        const arg = String(ctx.args || "").trim().toLowerCase();
        if (!/^(on|off)$/.test(arg)) {
          return { text: "Auto-reply is currently *" + (runtime.autoReply ? "on" : "off") + "*. Use " + config.prefix + "autoreply on or " + config.prefix + "autoreply off." };
        }
        runtime.autoReply = arg === "on";
        return { text: "Auto-reply is now *" + arg + "*. " + (runtime.autoReply ? "I step in after " + Math.round(runtime.delayMs() / 60000) + " minutes of silence." : "I will not answer for you until you switch it back on.") };
      }
    },
    {
      name: "mode",
      owner: true,
      description: "public — chat with everyone; private — only the owner",
      run: ctx => {
        const arg = String(ctx.args || "").trim().toLowerCase();
        if (!/^(public|private)$/.test(arg)) {
          return { text: "Current mode is *" + runtime.mode + "*. Use " + config.prefix + "mode public or " + config.prefix + "mode private." };
        }
        runtime.mode = arg;
        return { text: "Mode is now *" + arg + "*. " + (arg === "private" ? "I only serve " + config.creatorName + " from here on." : "I chat with everyone who messages you.") };
      }
    },
    {
      name: "setdelay",
      owner: true,
      description: "change the wait before I step in (1-60 minutes)",
      run: ctx => {
        const minutes = Number(String(ctx.args || "").replace(/\D/g, ""));
        if (!minutes || minutes < 1 || minutes > 60) {
          return { text: "Send " + config.prefix + "setdelay 5 — a whole number of minutes between 1 and 60. Right now I wait " + Math.round(runtime.delayMs() / 60000) + "." };
        }
        runtime.delayMs = () => minutes * 60000;
        return { text: "Done — I now step in after *" + minutes + " minute" + (minutes === 1 ? "" : "s") + "* of silence." };
      }
    },
    {
      name: "reset",
      owner: true,
      description: "wipe this chat's conversation memory",
      run: ctx => {
        runtime.resetChat(ctx.jid);
        return { text: "Memory cleared for this chat. Fresh start. 🧹" };
      }
    }
  ];

  const lookup = new Map();
  for (const command of commands) {
    lookup.set(command.name, command);
    for (const alias of command.aliases || []) lookup.set(alias, command);
  }
  return { commands, lookup };
}

export function resolveCommand(text, prefix, lookup) {
  const value = String(text || "").trim();
  if (!value.startsWith(prefix)) return null;
  const body = value.slice(prefix.length).trim();
  if (!body) return null;
  const parts = body.split(/\s+/);
  const command = lookup.get(parts[0].toLowerCase());
  if (!command) return null;
  return { command, args: parts.slice(1).join(" ") };
}
