import { lagosClock, prettyNumber, uptimeText } from "./utils.js";

// Mathematical Sans-Serif Bold — the DamzD family look for section labels.
// Plain punctuation (spaces, dots, dashes, &) passes through untouched.
function mbold(text) {
  return String(text).split("").map(ch => {
    const code = ch.codePointAt(0);
    if (code >= 65 && code <= 90) return String.fromCodePoint(0x1d5d4 + code - 65);
    if (code >= 97 && code <= 122) return String.fromCodePoint(0x1d5ee + code - 97);
    if (code >= 48 && code <= 57) return String.fromCodePoint(0x1d7ec + code - 48);
    return ch;
  }).join("");
}

const BOX_TOP = "╭──〔 ";
const BOX_LINE = "│  ";
const BOX_BOTTOM = "╰────────────────";
const MENU_ENDING = "✦ " + mbold("POWERED BY GREAT DAMZD");

function header(config) {
  return BOX_TOP + "⚡ " + config.botName + " 〕";
}

function row(label, value) {
  return BOX_LINE + "◇ " + mbold(label) + ": " + value;
}

function section(title) {
  return BOX_TOP + mbold(title) + " 〕";
}

// The menu text — ONE string, always sent as a single message right after the
// bot picture. Never split, never chunked.
export function menuText(config, stats = {}) {
  const delayMinutes = stats.delayMinutes || Math.round(config.autoReplyDelayMs / 60000);
  const lines = [
    header(config),
    row("NAME", config.aiName),
    row("VERSION", config.version),
    row("MODE", stats.mode || config.mode),
    row("PREFIX", config.prefix),
    row("AUTO-REPLY", stats.autoReply ? "on — I answer for you after " + delayMinutes + " min of silence" : "off"),
    row("MY TIME", lagosClock(config) + " WAT"),
    "",
    section("OWNER"),
    row("CREATOR", config.creatorName),
    row("INFO", config.creatorInfo),
    row("NUMBER", prettyNumber(config.ownerNumber)),
    "",
    section("WHAT I DO"),
    BOX_LINE + config.aiHelpsWith,
    BOX_LINE + "Chat with me in plain words — no " + config.prefix + " needed. Dot commands are below.",
    "",
    section("COMMANDS"),
    BOX_LINE + "› " + config.prefix + "menu — this menu",
    BOX_LINE + "› " + config.prefix + "help — the full guide",
    BOX_LINE + "› " + config.prefix + "ping — check I am alive",
    BOX_LINE + "› " + config.prefix + "autoreply on/off — owner only",
    BOX_LINE + "› " + config.prefix + "mode public/private — owner only",
    BOX_LINE + "› " + config.prefix + "setdelay <minutes> — owner only",
    BOX_LINE + "› " + config.prefix + "reset — owner only, wipes this chat's memory",
    "",
    BOX_BOTTOM
  ];
  return lines.join("\n") + "\n\n" + MENU_ENDING;
}

// The .help guide — ONE string after the bot picture. It explains the whole
// flow in plain language: how the 5-minute auto-reply works, what stands the
// AI down, and every command with a usage example.
export function helpText(config) {
  const minutes = Math.round(config.autoReplyDelayMs / 60000);
  return [
    header(config),
    "",
    section("HOW I WORK"),
    BOX_LINE + "1. A message arrives in one of " + config.creatorName + "'s chats.",
    BOX_LINE + "2. If he does not reply within " + minutes + " minute" + (minutes === 1 ? "" : "s") + ", I step in and answer as his assistant.",
    BOX_LINE + "3. While he is away I keep the conversation going, one reply per message.",
    BOX_LINE + "4. The moment he replies himself, I stand down for " + config.ownerActiveMinutes + " minutes so I never talk over him.",
    BOX_LINE + "5. Every reply I send carries the ✦ " + config.aiName + " tag — nobody mistakes me for him.",
    "",
    section("NO DOT NEEDED"),
    BOX_LINE + "Just type to me like a person: \"how far\" gets an answer.",
    BOX_LINE + "Commands use the dot so I can tell them apart from chat: " + config.prefix + "menu.",
    "",
    section("COMMANDS"),
    BOX_LINE + "› " + config.prefix + "menu — the info card (picture first, then everything)",
    BOX_LINE + "› " + config.prefix + "help — this guide",
    BOX_LINE + "› " + config.prefix + "ping — am I alive and how long have I been up",
    BOX_LINE + "› " + config.prefix + "autoreply on|off — turn the 5-minute answers on or off (owner)",
    BOX_LINE + "› " + config.prefix + "mode public|private — public chats with everyone, private only serves " + config.creatorName + " (owner)",
    BOX_LINE + "› " + config.prefix + "setdelay 5 — change the wait before I step in, 1-60 minutes (owner)",
    BOX_LINE + "› " + config.prefix + "reset — forget this chat's conversation history (owner)",
    "",
    BOX_BOTTOM,
    "",
    "In groups I only speak when someone mentions me, and only in public mode.",
    MENU_ENDING
  ].join("\n");
}

// The connect note — sent to the owner's own chat right after the bot picture
// whenever the bot really comes online (fresh pairing or a restart; socket
// recycles never re-announce). ONE unbroken message.
export function connectNote(config, info = {}) {
  const lines = [
    header(config),
    row("STATUS", "connected and online ✅"),
    row("VERSION", config.version),
    row("LINKED AS", info.number ? "+" + info.number : "your WhatsApp"),
    row("MY TIME", lagosClock(config) + " WAT"),
    "",
    section("WHAT I DO"),
    BOX_LINE + config.aiHelpsWith,
    BOX_LINE + "Auto-reply is " + (info.autoReply ? "ON" : "OFF") + " — I step in after " + Math.round(config.autoReplyDelayMs / 60000) + " min of silence.",
    "",
    section("TRY ME"),
    BOX_LINE + "› " + config.prefix + "menu — the full card",
    BOX_LINE + "› " + config.prefix + "help — how everything works",
    BOX_LINE + "› Just talk to me in plain words, no dot needed.",
    "",
    BOX_BOTTOM
  ];
  return lines.join("\n") + "\n\n" + MENU_ENDING;
}
