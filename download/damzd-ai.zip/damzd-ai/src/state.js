// The auto-reply timing brain — pure logic, no WhatsApp, fully testable.
//
// Per chat:
//   incoming message  → arm a timer (5 min default) unless the owner is
//                       around or the AI is already in a live conversation
//   timer fires       → the AI sends its first reply, conversation goes live
//   live conversation → every further message gets a timely AI reply
//                       (respecting the per-chat cooldown)
//   owner replies     → stand down: timer dropped, live chat closed, and the
//                       owner is marked present for ownerActiveMinutes

export function makeAutoReply(config) {
  const armed = new Map();      // chat -> deadline (ms epoch) while waiting
  const live = new Map();       // chat -> true while the AI is conversing
  const ownerUntil = new Map(); // chat -> owner-present window end
  const lastReply = new Map();  // chat -> last AI reply time

  const cooldownMs = () => Math.max(0, config.cooldownSeconds) * 1000;

  return {
    onIncoming(chat, now) {
      if (live.get(chat)) {
        if (now - (lastReply.get(chat) || 0) < cooldownMs()) return "cooldown";
        return "reply-now";
      }
      if ((ownerUntil.get(chat) || 0) > now) return "idle";
      if (armed.has(chat)) return "waiting";
      armed.set(chat, now + config.autoReplyDelayMs);
      return "armed";
    },

    // The deadline passed? One-shot: true on the first tick past it.
    tick(chat, now) {
      const deadline = armed.get(chat) || 0;
      if (!deadline || now < deadline) return false;
      armed.delete(chat);
      live.set(chat, true);
      lastReply.set(chat, now);
      return true;
    },

    onOwnerMessage(chat, now) {
      armed.delete(chat);
      live.delete(chat);
      ownerUntil.set(chat, now + config.ownerActiveMinutes * 60000);
      return "stand-down";
    },

    noteReply(chat, now) {
      lastReply.set(chat, now);
    },

    // A live conversation may reply now without breaking the cooldown?
    canReplyNow(chat, now) {
      return now - (lastReply.get(chat) || 0) >= cooldownMs();
    },

    isLive(chat) {
      return Boolean(live.get(chat));
    },

    reset(chat) {
      armed.delete(chat);
      live.delete(chat);
      ownerUntil.delete(chat);
      lastReply.delete(chat);
    },

    chats() {
      return new Set([...armed.keys(), ...live.keys(), ...ownerUntil.keys()]);
    },

    snapshot() {
      return {
        armedChats: armed.size,
        liveChats: live.size,
        ownerPresentChats: ownerUntil.size
      };
    }
  };
}
