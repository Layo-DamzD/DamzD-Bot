import makeWASocket, {
  Browsers,
  DisconnectReason,
  fetchLatestWaWebVersion,
  useMultiFileAuthState
} from "baileys";
import fs from "node:fs";
import path from "node:path";
import pino from "pino";

import { config } from "../config.js";
import { numberFromJid, sleep, botImagePayload } from "./utils.js";
import { connectNote } from "./menus.js";
import { askAI } from "./ai.js";
import { makeAutoReply } from "./state.js";
import { createCommands, resolveCommand } from "./commands.js";

const logger = pino({ level: "warn" });
const TICK_MS = 15000;
const MIN_PAIRING_INTERVAL_MS = 25000;

// Mutable runtime state (things the owner can change live with commands).
export function createRuntime() {
  const runtime = {
    mode: config.mode,
    autoReply: config.autoReply,
    startedAt: Date.now(),
    delayMs: () => config.autoReplyDelayMs,
    history: new Map(),   // chat -> [{ role, content }] (maxHistory turns)
    pending: new Map(),   // chat -> latest text while the timer is armed
    resetChat(jid) {
      runtime.state.reset(jid);
      runtime.history.delete(jid);
      runtime.pending.delete(jid);
    }
  };
  // The timing brain reads the live values (setdelay can move the delay).
  const stateConfig = {
    get autoReplyDelayMs() { return runtime.delayMs(); },
    get cooldownSeconds() { return config.cooldownSeconds; },
    get ownerActiveMinutes() { return config.ownerActiveMinutes; }
  };
  runtime.state = makeAutoReply(stateConfig);
  const { commands, lookup } = createCommands({ config, runtime });
  runtime.commands = commands;
  runtime.lookup = lookup;
  return runtime;
}

export async function startBot({ runtime, dashboard }) {
  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDirectory);
  // fetchLatestWaWebVersion is known to hang on some networks — never let it
  // block the boot, and only pass the plain version array through.
  let version;
  try {
    const fetched = await Promise.race([
      fetchLatestWaWebVersion().catch(() => null),
      sleep(6000).then(() => null)
    ]);
    if (Array.isArray(fetched?.version)) version = fetched.version;
  } catch {
    version = undefined;
  }

  const sock = makeWASocket({
    version,
    auth: state,
    browser: Browsers.ubuntu("Chrome"),
    logger,
    markOnlineOnConnect: false,
    syncFullHistory: false
  });

  // The bot is a linked device on the owner's account, so WhatsApp
  // re-delivers everything this account sends — register our own sends as
  // processed so an AI reply can never trigger another reply (self-loop).
  const processed = new Set();
  const rawSend = sock.sendMessage.bind(sock);
  sock.sendMessage = async (jid, content, options) => {
    const sent = await rawSend(jid, content, options);
    const sentId = String(sent?.key?.id || "");
    if (sentId) processed.add(sentId);
    return sent;
  };

  sock.ev.on("creds.update", saveCreds);

  // ---- pairing code: requested on each fresh QR, throttled, generation-guarded
  let stopped = false;
  let lastPairingIssueAt = 0;
  let pairingGeneration = 0;
  async function requestPairing() {
    if (state.creds?.registered) return;
    const now = Date.now();
    if (lastPairingIssueAt && now - lastPairingIssueAt < MIN_PAIRING_INTERVAL_MS) return;
    lastPairingIssueAt = now;
    const generation = ++pairingGeneration;
    const target = runtime.pairOverrideNumber || config.pairNumber;
    try {
      const code = await sock.requestPairingCode(target);
      if (generation === pairingGeneration && dashboard) dashboard.setPairingCode(code);
      logger.info("pairing code issued for +" + target);
      return code;
    } catch (error) {
      logger.warn({ error }, "pairing code request failed — the next QR retries");
      return null;
    }
  }

  // The dashboard's "Get pairing code" button drives this: it forces a fresh
  // request on the live socket for the number typed in (default PAIR_NUMBER).
  runtime.triggerPairing = number => {
    if (number) runtime.pairOverrideNumber = String(number).replace(/\D/g, "");
    lastPairingIssueAt = 0;
    return requestPairing();
  };

  let introSent = false;  sock.ev.on("connection.update", async update => {
    const { connection, lastDisconnect } = update;
    if (update.qr) {
      if (dashboard) await dashboard.setQr(update.qr).catch?.(() => {});
      requestPairing().catch(() => {});
    }
    if (connection === "open") {
      if (dashboard) {
        dashboard.setPairingCode(null);
        dashboard.setConnected(true, numberFromJid(sock.user?.id || ""));
      }
      console.log("[" + config.botName + "] connected as " + (sock.user?.id || "unknown"));
      // First stable connection of this run: the bot picture goes first, then
      // the connect note as ONE unbroken message, straight to the owner's own
      // chat. Socket recycles keep this quiet — only a real start announces.
      if (!introSent) {
        introSent = true;
        const ownerJid = config.ownerNumber + "@s.whatsapp.net";
        const picture = botImagePayload(config);
        if (picture) rawSend(ownerJid, picture).catch(() => {});
        rawSend(ownerJid, {
          text: connectNote(config, {
            number: numberFromJid(sock.user?.id || ""),
            autoReply: runtime.autoReply
          })
        }).catch(() => {});
      }
    }
    if (connection === "close") {
      if (dashboard) dashboard.setConnected(false, null);
      const code = Number(
        lastDisconnect?.error?.output?.statusCode ||
        lastDisconnect?.error?.data?.statusCode ||
        0
      );
      if (code === DisconnectReason.loggedOut || code === 401) {
        console.error("[" + config.botName + "] session was rejected — wiping it for a clean re-pair");
        try { fs.rmSync(path.resolve(config.sessionDirectory), { recursive: true, force: true }); } catch { /* nothing to wipe */ }
      }
      if (!stopped) {
        await sleep(4000);
        startBot({ runtime, dashboard }).catch(() => {});
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      try { await handleMessage({ sock, rawSend, processed, msg, runtime, dashboard }); }
      catch (error) { logger.warn({ error }, "message handling failed"); }
    }
  });

  // The 5-minute watch: every tick checks the armed chats; one whose deadline
  // passed gets the AI's first reply (with the intro line), and the chat goes
  // live from then on.
  const timer = setInterval(() => {
    const now = Date.now();
    for (const chat of runtime.state.chats()) {
      if (!runtime.state.tick(chat, now)) continue;
      const prompt = runtime.pending.get(chat) || "";
      runtime.pending.delete(chat);
      aiReplyNow({ sock, runtime, jid: chat, prompt, intro: true }).catch(() => {});
    }
  }, TICK_MS);
  if (timer.unref) timer.unref();

  return { sock, stop: () => { stopped = true; clearInterval(timer); sock.end?.(); } };
}

// ---- message pipeline -------------------------------------------------------

function messageText(message) {
  const value = message || {};
  return String(
    value.conversation ||
    value.extendedTextMessage?.text ||
    value.imageMessage?.caption ||
    value.videoMessage?.caption ||
    ""
  ).trim();
}

async function handleMessage({ sock, rawSend, processed, msg, runtime, dashboard }) {
  const key = msg?.key;
  const jid = String(key?.remoteJid || "");
  if (!jid || jid === "status@broadcast" || jid.endsWith("@newsletter")) return;
  const id = String(key?.id || "");
  if (id) {
    if (processed.has(id)) return;
    processed.add(id);
    if (processed.size > 2000) processed.delete(processed.keys().next().value);
  }

  const text = messageText(msg.message);
  if (!text) return;

  const fromMe = Boolean(key.fromMe);
  const senderNumber = numberFromJid(key.participant || (fromMe ? sock.user?.id : jid));
  const isOwner = fromMe || senderNumber === config.ownerNumber;
  const isGroup = jid.endsWith("@g.us");

  const send = content => sock.sendMessage(jid, content);
  const reply = textOut => send({ text: textOut });
  const ctx = { sock, msg, jid, text, fromMe, isOwner, isGroup, senderNumber, send, reply, args: "" };

  // The owner speaking (a reply or a command) always stands the AI down here.
  if (fromMe) runtime.state.onOwnerMessage(jid, Date.now());

  // Dot commands — the control surface. Owner-only ones are silently skipped
  // for anyone else.
  const parsed = resolveCommand(text, config.prefix, runtime.lookup);
  if (parsed) {
    if (parsed.command.owner && !isOwner) return;
    ctx.args = parsed.args;
    await sendAction(jid, parsed.command.run(ctx), sock);
    return;
  }

  if (fromMe) return; // the owner's plain outgoing texts are never answered

  // Groups: only when the bot is mentioned, and only in public mode.
  if (isGroup) {
    if (runtime.mode !== "public") return;
    const mentioned = (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [])
      .some(j => numberFromJid(j) === numberFromJid(sock.user?.id || ""));
    if (!mentioned && !text.includes("@" + numberFromJid(sock.user?.id || ""))) return;
    await aiReplyNow({ sock, runtime, jid, prompt: text, intro: false });
    return;
  }

  // Private mode: the AI only serves the owner's own account.
  if (runtime.mode !== "public") return;

  // The auto-reply flow: arm the timer, or answer live if the conversation
  // with this person is already going (cooldown respected).
  const verdict = runtime.state.onIncoming(jid, Date.now());
  if (verdict === "armed" || verdict === "waiting") runtime.pending.set(jid, text);
  if (verdict === "reply-now") {
    runtime.pending.set(jid, text);
    await aiReplyNow({ sock, runtime, jid, prompt: text, intro: false });
  }
}

// ---- sending ---------------------------------------------------------------

// The signature pattern for image-first actions: the picture goes out, then
// the text as ONE unbroken message — never split.
export async function sendAction(jid, action, sock, configRef = config) {
  if (action?.image) {
    const picture = botImagePayload(configRef);
    if (picture) {
      try { await sock.sendMessage(jid, picture); } catch { /* picture is decorative */ }
    }
  }
  if (action?.text) await sock.sendMessage(jid, { text: String(action.text) });
}

function historyFor(runtime, jid) {
  return runtime.history.get(jid) || [];
}

function pushHistory(runtime, jid, role, content) {
  const list = runtime.history.get(jid) || [];
  list.push({ role, content: String(content || "").slice(0, 3500) });
  while (list.length > config.maxHistory * 2) list.shift();
  runtime.history.set(jid, list);
}

export async function aiReplyNow({ sock, runtime, jid, prompt, intro }) {
  if (prompt) pushHistory(runtime, jid, "user", prompt);
  try {
    await sock.sendPresenceUpdate("composing", jid);
    await sleep(1200);
    const answer = await askAI({ history: historyFor(runtime, jid), prompt: "" });
    pushHistory(runtime, jid, "assistant", answer);
    runtime.state.noteReply(jid, Date.now());
    const parts = [];
    if (intro) {
      parts.push("Hi! " + config.creatorName + " is away at the moment — I'm his AI, " + config.aiName + ".");
      parts.push(answer);
    } else {
      parts.push(answer);
    }
    let textOut = parts.join(" ");
    if (config.aiSignature) textOut += "\n\n✦ " + config.aiName;
    await sock.sendMessage(jid, { text: textOut });
  } catch (error) {
    // Failures stay quiet in the original chat: nobody but the chat sees a
    // short apology, and the owner never gets spammed.
    await sock.sendMessage(jid, { text: "Give me a second — my brain blinked. Try me again. ✦ " + config.aiName }).catch(() => {});
  }
}
