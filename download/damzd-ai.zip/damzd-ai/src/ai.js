import { config } from "../config.js";

// DamzD AI's brain — the owner's Puter accounts unlock the real flagship
// models through puter.ai.chat. Several tokens can be supplied
// comma-separated (GROQ_API_KEY / PUTER_AUTH_TOKEN); calls rotate through
// them round-robin and an account that fails is skipped for that request.
// The SDK is imported lazily so the bot still boots before the package or
// token exists — that brain simply sleeps and the keyless service answers.
export function systemPrompt() {
  const parts = [
    `You are ${config.aiName}, the WhatsApp assistant set up by ${config.creatorName} (${config.creatorInfo}).`,
    `You answer in his chats when he is away: a message sat ${Math.round(config.autoReplyDelayMs / 60000)} minutes without a reply from him, so you stepped in as his assistant.`,
    "How you write:",
    "- Warm, calm, proper sentences — like a thoughtful person texting, not a call-centre script.",
    "- Keep it short: 1-4 sentences unless the question truly needs more.",
    "- Plain WhatsApp text; *asterisks* make words bold — use sparingly.",
    "- At most one emoji per message, and only when it genuinely fits.",
    "- No robotic boilerplate: no 'Is there anything else', no sign-offs, no bullet lists unless asked.",
    "- Never advertise anything, never add links, signatures or credits. The app adds the ✦ tag itself when needed.",
    "How you behave:",
    `- If someone asks whether you are a bot or the AI, answer honestly and lightly: yes, you are ${config.aiName}, answering while ${config.creatorName} is away — then carry on with the conversation.`,
    "- If you are unsure about something, say so plainly instead of inventing facts.",
    "- Match the language the person writes in — English, pidgin, Yoruba, anything.",
    "- You may be playful when the mood is playful, but you never lose your manners."
  ];
  if (config.reasoningEffort === "high") {
    parts.push("Reasoning effort is high: think each answer through carefully before writing; accuracy matters more than speed.");
  }
  return parts.join(" ");
}

function stripThinking(text) {
  return String(text || "")
    .replace(/<think>[\s\S]*?<\/think>/gi, "")
    .trim();
}

let puterCursor = 0;
const puterClients = new Map();
async function getPuterFor(token) {
  if (!puterClients.has(token)) {
    const { init } = await import("@heyputer/puter.js/src/init.cjs");
    puterClients.set(token, init(token));
  }
  return puterClients.get(token);
}

function puterText(result) {
  const content = result?.message?.content ?? result?.toString?.() ?? result;
  if (Array.isArray(content)) {
    return content.map(part => (typeof part === "string" ? part : part?.text || "")).join("").trim();
  }
  return String(content || "").trim();
}

async function callPuterModel(chat, model) {
  const tokens = config.puterTokens;
  if (!tokens.length) throw new Error("no-key");
  let lastError = null;
  for (let attempt = 0; attempt < tokens.length; attempt++) {
    const token = tokens[(puterCursor + attempt) % tokens.length];
    try {
      const puter = await getPuterFor(token);
      const answer = await Promise.race([
        puter.ai.chat(chat, { model }),
        new Promise((_resolve, reject) =>
          setTimeout(() => reject(new Error("the Puter model took too long")), 90000))
      ]);
      const text = puterText(answer);
      if (!text) throw new Error("the Puter model had nothing to say.");
      puterCursor = (puterCursor + attempt + 1) % tokens.length;
      return stripThinking(text);
    } catch (error) {
      lastError = error;
      continue;
    }
  }
  throw lastError || new Error("the Puter models are quiet right now.");
}

// The latest flagships on Puter, probed live through puter.ai.chat with plain
// shorthand names (same probe set the main DamzD bot uses).
const PUTER_LATEST = {
  astra: "gpt-6-astra",
  sol: "gpt-6.1-sol",
  luna: "gpt-6-luna",
  opus: "claude-opus-5-5",
  sonnet: "claude-sonnet-5-5",
  fable: "claude-fable-5-2",
  flash: "gemini-3.8-flash"
};

// Read the question, pick the brain that is best at that kind of task, and
// keep a fallback ladder under every route so a sleeping model never
// dead-ends. (groqModel is "puter" per the spec — this router IS the model.)
const TASK_ROUTES = {
  code: [PUTER_LATEST.astra, PUTER_LATEST.sol, PUTER_LATEST.luna],
  math: [PUTER_LATEST.sol, PUTER_LATEST.astra, PUTER_LATEST.luna],
  creative: [PUTER_LATEST.fable, PUTER_LATEST.sol, PUTER_LATEST.luna],
  translate: [PUTER_LATEST.luna, PUTER_LATEST.sol, PUTER_LATEST.astra],
  chat: [PUTER_LATEST.sol, PUTER_LATEST.astra, PUTER_LATEST.luna]
};

export function classifyTask(prompt) {
  const text = String(prompt || "").toLowerCase();
  if (/(translate|translation|how do (you|i) say|what does .* mean in |in (yoruba|igbo|hausa|pidgin|french|spanish|german|arabic|chinese|japanese)\b)/.test(text)) return "translate";
  if (/(```|function\b|debug|bug\b|error\b|stack ?trace|code\b|coding|program|script\b|javascript|typescript|python\b|java\b|c\+\+|c#|php\b|sql\b|html\b|css\b|react\b|node\.?js|api\b|regex|algorithm|compile|npm\b|git\b|json\b|array\b|loop\b|variable|database|syntax)/.test(text)) return "code";
  if (/(solve|calculate|equation|arithmetic|\bmath|algebra|geometry|percentage|integral|derivative|probability|\d+\s*[+\-*/^×÷]\s*\d+)/.test(text)) return "math";
  if (/(story|poem|poetry|write me|write a|essay|lyrics|joke|caption|slogan|speech|imagine|roleplay|novel|rhyme|fairytale|fairy tale|bedtime)/.test(text)) return "creative";
  return "chat";
}

async function runPuterRoute(chat, route) {
  let routeError = null;
  for (const model of route) {
    try {
      return await callPuterModel(chat, model);
    } catch (error) {
      routeError = error;
    }
  }
  throw routeError || new Error("no model on the route answered");
}

// Keyless fallback so the bot keeps chatting even before any token is added.
async function callPollinations(chat) {
  const response = await fetch("https://text.pollinations.ai/openai", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ model: "openai", messages: chat }),
    signal: AbortSignal.timeout(90000)
  });
  if (!response.ok) throw new Error("the free AI service refused that request.");
  const payload = await response.json().catch(() => null);
  const text = payload?.choices?.[0]?.message?.content;
  if (!text || !String(text).trim()) throw new Error("the free AI service had nothing to say.");
  return stripThinking(text);
}

export async function askAI({ history = [], prompt }) {
  const trimmed = String(prompt || "").trim();
  const chat = [
    { role: "system", content: systemPrompt() },
    ...history.slice(-config.maxHistory * 2),
    ...(trimmed ? [{ role: "user", content: trimmed.slice(0, 3500) }] : [])
  ];
  const failures = [];
  if (config.puterTokens.length) {
    try {
      return await runPuterRoute(chat, TASK_ROUTES[classifyTask(prompt)] || TASK_ROUTES.chat);
    } catch (error) {
      failures.push(error?.message);
    }
  }
  try {
    return await callPollinations(chat);
  } catch (error) {
    failures.push(error?.message);
  }
  throw new Error("every AI service is quiet right now. Try again in a moment." +
    (failures.length ? " (" + failures[0] + ")" : ""));
}
