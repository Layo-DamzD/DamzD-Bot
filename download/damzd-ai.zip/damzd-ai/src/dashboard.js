import http from "node:http";
import QRCode from "qrcode";

// The pairing + health dashboard: one page with the QR to scan, the 8-digit
// pairing code when one is active, and the bot's live status. Plain node http
// — no framework, light enough for KataBump's smallest free server.

export function startDashboard(port, config, getState) {
  const state = {
    qrDataUrl: null,
    pairingCode: null,
    connected: false,
    number: null,
    pairRequest: null // set by the bot: async (number) => code
  };

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, "http://" + (req.headers.host || "localhost"));
    if (url.pathname === "/status") {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({
        connected: state.connected,
        number: state.number,
        hasQr: Boolean(state.qrDataUrl),
        pairingCode: state.pairingCode,
        bot: config.botName,
        version: config.version,
        mode: getState()?.mode,
        autoReply: getState()?.autoReply,
        uptimeMs: getState()?.startedAt ? Date.now() - getState().startedAt : 0,
        timing: getState()?.state?.snapshot?.() || null
      }));
      return;
    }
    if (url.pathname === "/pair" && req.method === "POST") {
      let body = "";
      for await (const chunk of req) body += chunk;
      let number = config.pairNumber;
      try { number = String(JSON.parse(body).number || "").replace(/\D/g, "") || config.pairNumber; } catch { /* default */ }
      let code = null;
      if (state.pairRequest) {
        try { code = await state.pairRequest(number); } catch { code = null; }
      }
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ ok: Boolean(code), code }));
      return;
    }
    // The page itself — plain HTML, responsive, auto-refreshing.
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    const snap = getState()?.state?.snapshot?.() || {};
    const html = `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="5">
<title>${config.botName} — dashboard</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#0b1020;color:#e8ecff;margin:0;padding:24px;text-align:center}
  .card{max-width:520px;margin:18px auto;background:#141a33;border:1px solid #2a3358;border-radius:16px;padding:22px}
  h1{font-size:1.4rem;margin:0 0 4px} .sub{color:#9aa6d6;font-size:.9rem}
  .status{font-size:1.05rem;margin:10px 0}
  .on{color:#5be49b}.off{color:#ff9d6b}
  img.qr{width:240px;height:240px;border-radius:12px;background:#fff;padding:8px}
  .code{font-size:2rem;letter-spacing:.35em;font-weight:700;color:#ffd166;margin:8px 0}
  input{padding:10px 12px;border-radius:10px;border:1px solid #2a3358;background:#0b1020;color:#e8ecff;width:200px;font-size:1rem}
  button{padding:10px 16px;border-radius:10px;border:0;background:#4f6df5;color:#fff;font-size:1rem;cursor:pointer}
  .row{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
  .kv{color:#9aa6d6;font-size:.85rem;margin:4px 0}
</style></head><body>
<div class="card">
  <h1>⚡ ${config.botName} ⚡</h1>
  <div class="sub">${config.creatorName} — ${config.creatorInfo} · v${config.version}</div>
  <div class="status ${state.connected ? "on" : "off"}">${state.connected ? "🟢 Connected as +" + (state.number || "") : "🟠 Waiting for pairing"}</div>
  ${state.connected ? "" : state.qrDataUrl ? `<img class="qr" src="${state.qrDataUrl}" alt="QR"><div class="kv">WhatsApp → Linked devices → Link a device</div>` : "<div class=\"kv\">Waiting for a QR from WhatsApp…</div>"}
  ${!state.connected && state.pairingCode ? `<div class="kv">Or link with a code — WhatsApp → Linked devices → Link with phone number:</div><div class="code">${state.pairingCode}</div>` : ""}
  ${!state.connected ? `<form class="row" onsubmit="pair(event)"><input id="num" value="${config.pairNumber}" inputmode="numeric"><button type="submit">Get pairing code</button></form>` : ""}
  <div class="kv">Mode: ${getState()?.mode || config.mode} · Auto-reply: ${getState()?.autoReply ? "on" : "off"} · Uptime: ${Math.floor((Date.now() - (getState()?.startedAt || Date.now())) / 60000)} min</div>
  <div class="kv">Timing: ${snap.armedChats || 0} waiting · ${snap.liveChats || 0} live chats · ${snap.ownerPresentChats || 0} owner-present</div>
</div>
<script>
async function pair(e){e.preventDefault();const b=document.getElementById("num").value.replace(/\\D/g,"");const r=await fetch("/pair",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({number:b})});const j=await r.json();if(j.code){document.querySelectorAll(".code").forEach(x=>x.remove());const d=document.createElement("div");d.className="code";d.textContent=j.code;document.querySelector(".card").appendChild(d);}}
</script>
</body></html>`;
    res.end(html);
  });

  server.listen(port, () => {
    console.log("[" + config.botName + "] dashboard on http://localhost:" + port);
  });

  return {
    async setQr(qr) {
      try { state.qrDataUrl = await QRCode.toDataURL(qr, { margin: 2, width: 320 }); }
      catch { state.qrDataUrl = null; }
    },
    setPairingCode(code) { state.pairingCode = code ? String(code).replace(/(\d{4})(?=\d)/g, "$1-") : null; },
    setConnected(connected, number) {
      state.connected = connected;
      state.number = number;
      if (connected) { state.qrDataUrl = null; state.pairingCode = null; }
    },
    onPairRequest(fn) { state.pairRequest = fn; },
    server
  };
}
