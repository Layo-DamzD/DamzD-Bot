import fs from "node:fs";
import path from "node:path";

export function numberFromJid(value) {
  return String(value || "").split("@")[0].split(":")[0].replace(/\D/g, "");
}

export function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// +2347087299884 → "+234 708 729 9884" — pretty form for menus and cards.
export function prettyNumber(number) {
  const digits = String(number || "").replace(/\D/g, "");
  if (digits.length < 7) return "+" + digits;
  const rest = digits.slice(3);
  return "+" + digits.slice(0, 3) + " " + rest.slice(0, 3) + " " + rest.slice(3, 6) + " " + rest.slice(6);
}

export function lagosClock(config) {
  try {
    const text = new Intl.DateTimeFormat("en-GB", {
      hour: "2-digit",
      minute: "2-digit",
      timeZone: config.timezone || "Africa/Lagos"
    }).format(new Date());
    return text;
  } catch {
    return new Date().toISOString().slice(11, 16);
  }
}

export function uptimeText(from) {
  let seconds = Math.floor((Date.now() - from) / 1000);
  const minutes = Math.floor(seconds / 60);
  seconds %= 60;
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days) return days + "d " + (hours % 24) + "h " + (minutes % 60) + "m";
  if (hours) return hours + "h " + (minutes % 60) + "m";
  if (minutes) return minutes + "m " + seconds + "s";
  return seconds + "s";
}

// The bot picture: an https URL passes straight through, a local file is read
// once and cached. Null when nothing usable is set, so callers simply skip
// the picture — the text still goes out.
let cachedImage;
let cachedFor = "";
export function botImagePayload(config) {
  const source = String(config?.botImage || "").trim();
  if (!source) return null;
  if (/^https?:\/\//i.test(source)) return { image: { url: source } };
  try {
    if (cachedFor !== source) {
      cachedImage = fs.readFileSync(path.resolve(source));
      cachedFor = source;
    }
    return { image: cachedImage };
  } catch {
    return null;
  }
}
