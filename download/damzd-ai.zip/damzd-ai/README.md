# ⚡ DamzD AI ⚡

**Great_DamzD's WhatsApp auto-reply assistant** — a linked device on his own
number that answers his chats when he does not reply within **5 minutes** of a
delivered message. It chats like a person, keeps conversations going while he
is away, and stands down the moment he is back. No ads, no footers, no spam.

- **Bot / AI name:** DamzD AI
- **Creator:** Great_DamzD — Software developer
- **Owner / pair number:** +234 708 729 9884
- **Runs on:** KataBump's lowest free server (or any Node 18+ host — Render, Railway, Termux)
- **Version:** 1.0.0 · **Timezone:** Africa/Lagos · **Prefix:** `.`

---

## What it does

1. A message arrives in one of the owner's chats (DM or group).
2. If he does not reply within **5 minutes**, DamzD AI steps in: it sends one
   reply that opens the conversation politely
   (*"Hi! Great_DamzD is away at the moment — I'm his AI, DamzD AI."*).
3. While he is away it keeps chatting with that person — every new message
   gets a timely answer (max **6 turns** of memory, **5s** cooldown per chat).
4. The moment the owner sends anything in the chat himself, the AI **stands
   down for 15 minutes** so it never talks over him.
5. Every AI-sent reply carries the **✦ DamzD AI** tag, so nobody mistakes it
   for him typing. (`AI_SIGNATURE=false` turns the tag off.)

Other behaviours:

- **Connect note:** on every real start (fresh pairing or restart) the owner's
  own chat receives the **bot picture first**, then a styled
  *"connected and online"* card — socket recycles stay silent, so no spam.
- **`.menu` and `.help` open with the bot picture first**, then the full text
  as **ONE unbroken message** — never split into chunks.
- **No dot needed to chat:** plain messages in DMs are the conversation.
  The dot is only for commands (see below).
- **Groups:** the AI only speaks when someone @-mentions it, and only in
  public mode.
- **Modes:** `public` (default) chats with everyone; `private` only serves the
  owner's own account.

## Commands

| Command | Who | What it does |
| --- | --- | --- |
| `.menu` | everyone | the info card — picture first, then everything |
| `.help` | everyone | how the auto-reply works + every command |
| `.ping` | everyone | online check + uptime |
| `.autoreply on\|off` | owner | turn the 5-minute answers on or off |
| `.mode public\|private` | owner | who the AI may talk to |
| `.setdelay 5` | owner | change the wait before it steps in (1–60 min) |
| `.reset` | owner | wipe the current chat's memory |

Owner = messages sent from the owner's own account (the bot runs as a linked
device on his WhatsApp).

## The brain

`GROQ_MODEL: puter` — the AI runs on the owner's **Puter accounts** through
`puter.ai.chat` with the real flagships (GPT-6 Astra/Sol, Claude, Gemini).
Paste several tokens comma-separated into `GROQ_API_KEY` ("our puter keys");
calls rotate round-robin and skip any account that fails. Questions are routed
by kind (code → Astra, maths → Sol, stories → Fable, quick → Luna), and a
keyless Pollinations service keeps it chatting even before any token is added.
`REASONING_EFFORT: high` makes it think before answering.

## Setup

```bash
npm install
npm test        # 11 offline checks — config, menus, timing brain
npm start
```

1. Copy `.env.example` to `.env` and fill in your values (the file ships with
   every value from the spec already set).
2. `npm start` — the dashboard opens on **http://localhost:3000** (use
   `PORT` to change it).
3. **Pair the bot** (2-minute job, done by whoever controls the phone):
   - open the dashboard and scan the **QR** — WhatsApp → *Linked devices* →
     *Link a device*; or
   - press **Get pairing code** and enter the 8-digit code in WhatsApp →
     *Linked devices* → *Link with phone number*.
4. The moment it connects, the owner's chat gets the picture + the
   *"connected and online"* card. That's it — it is watching.

> **Under parental control?** Pairing must be approved from the phone itself —
> it is the same "Linked devices" screen you already know. Whoever holds the
> phone does the 2-minute scan/code step; the bot does everything else.

## Deploying to KataBump

1. Create a **Node.js** server on KataBump (the lowest free plan is enough —
   the bot is one small process, no heavy dependencies).
2. Upload the project zip through the file manager (or connect the GitHub
   repo if your panel supports it).
3. Set the **start command** to `node server.js` and add your environment
   variables (or upload a `.env`).
4. Open the server's port URL — that is the dashboard — and pair with the QR
   or the pairing code.
5. If your plan idles the server, point an external uptime-ping at the
   dashboard URL to keep it awake.

On Render instead: `node server.js`, same steps — the dashboard port is
`PORT` (default 3000).

## Files

```
server.js          entry — starts the dashboard and the bot
config.js          every spec value, env-overridable
src/menus.js       menu / help / connect note builders (one message each)
src/state.js       the 5-minute auto-reply timing brain (pure, tested)
src/ai.js          Puter token rotation + task routing + fallback
src/commands.js    the dot commands (action objects, image-first handled here)
src/bot.js         WhatsApp connection, message pipeline, timers
src/dashboard.js   QR + pairing code + status page
assets/bot-image.png   the bot picture (BOT_IMAGE can point anywhere)
test/smoke.js      offline smoke checks
```

## Tuning

| Env | Default | Meaning |
| --- | --- | --- |
| `AUTO_REPLY_DELAY_MS` | `300000` | minutes of silence before the AI steps in |
| `OWNER_ACTIVE_MINUTES` | `15` | stand-down window after the owner replies |
| `MAX_HISTORY` | `6` | conversation turns kept per chat |
| `COOLDOWN_SECONDS` | `5` | minimum gap between AI replies in a live chat |
| `AI_SIGNATURE` | `true` | the ✦ DamzD AI tag on AI-sent replies |
| `BOT_IMAGE` | bundled file | the picture — local file or https URL |
