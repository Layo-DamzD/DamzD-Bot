import { config } from "./config.js";
import { startBot, createRuntime } from "./src/bot.js";
import { startDashboard } from "./src/dashboard.js";

const runtime = createRuntime();
const dashboard = startDashboard(config.port, config, () => runtime);

// The dashboard's pairing-code button drives the same request path as the
// automatic QR-cycle flow — one code at a time, newest wins.
dashboard.onPairRequest(async number => {
  return runtime.triggerPairing(number);
});

process.on("unhandledRejection", error => {
  console.error("[" + config.botName + "] unhandled rejection:", error?.message || error);
});
process.on("uncaughtException", error => {
  console.error("[" + config.botName + "] uncaught exception:", error?.message || error);
});

await startBot({ runtime, dashboard });
