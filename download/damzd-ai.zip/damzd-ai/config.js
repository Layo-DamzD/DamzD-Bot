import dotenv from "dotenv";
dotenv.config();

// DamzD AI — every value from the owner's spec. Anything with an env var can
// be overridden from the host panel (KataBump, Render, Termux) without
// touching this file.
export const config = Object.freeze({
  botName: String(process.env.BOT_NAME || "DamzD AI").trim() || "DamzD AI",
  aiName: String(process.env.AI_NAME || "DamzD AI").trim() || "DamzD AI",
  creatorName: String(process.env.CREATOR_NAME || "Great_DamzD").trim() || "Great_DamzD",
  creatorInfo: String(process.env.CREATOR_INFO || "Software developer").trim() || "Software developer",
  ownerNumber: String(process.env.OWNER_NUMBER || "2347087299884").replace(/\D/g, ""),
  pairNumber: String(process.env.PAIR_NUMBER || process.env.OWNER_NUMBER || "2347087299884").replace(/\D/g, ""),
  // The owner's Puter tokens go here, comma-separated — the field keeps the
  // name his spec gave it (GROQ_API_KEY), but it carries "our puter keys".
  // Every call rotates through the accounts round-robin and skips any that
  // fail. With no tokens at all the keyless Pollinations service still chats.
  get puterTokens() {
    return [...new Set(
      String(process.env.GROQ_API_KEY || process.env.PUTER_AUTH_TOKEN || "")
        .split(",")
        .map(token => token.trim())
        .filter(Boolean)
    )];
  },
  groqModel: String(process.env.GROQ_MODEL || "puter").trim() || "puter",
  reasoningEffort: String(process.env.REASONING_EFFORT || "high").trim().toLowerCase() || "high",
  // The picture that opens .menu, .help and the connect note. A local file
  // (bundled assets/bot-image.png) or any https URL — e.g. the owner's
  // cloudinary link.
  botImage: String(process.env.BOT_IMAGE || "assets/bot-image.png").trim() || "assets/bot-image.png",
  aiHelpsWith: String(process.env.AI_HELPS_WITH ||
    "responding to your messages if you do not respond 5 minutes after delivery — I step in and answer for you while you are away").trim(),
  prefix: String(process.env.PREFIX || ".").slice(0, 3) || ".",
  mode: String(process.env.MODE || "public").trim().toLowerCase() === "private" ? "private" : "public",
  version: String(process.env.VERSION || "1.0.0").trim() || "1.0.0",
  timezone: String(process.env.TIMEZONE || "Africa/Lagos").trim() || "Africa/Lagos",
  autoReply: String(process.env.AUTO_REPLY || "true").trim().toLowerCase() !== "false",
  // 5 minutes after delivery — the spec. Can be tuned live with .setdelay.
  autoReplyDelayMs: Math.max(10_000, Number(process.env.AUTO_REPLY_DELAY_MS || 300000) || 300000),
  // After the owner replies in a chat, the AI stands down for this long so it
  // never talks over him while he is present.
  ownerActiveMinutes: Math.max(1, Number(process.env.OWNER_ACTIVE_MINUTES || 15) || 15),
  maxHistory: Math.max(2, Number(process.env.MAX_HISTORY || 6) || 6),
  cooldownSeconds: Math.max(0, Number(process.env.COOLDOWN_SECONDS || 5) || 5),
  // Every AI-sent reply carries the "✦ DamzD AI" tag so nobody mistakes it
  // for the owner typing. Set AI_SIGNATURE=false to turn the tag off.
  aiSignature: String(process.env.AI_SIGNATURE || "true").trim().toLowerCase() !== "false",
  sessionDirectory: String(process.env.SESSION_DIR || "./auth").trim() || "./auth",
  dataDirectory: String(process.env.DATA_DIR || "./data").trim() || "./data",
  port: Number(process.env.PORT || 3000) || 3000
});

export const HEADER = "⚡ " + config.botName + " ⚡";
