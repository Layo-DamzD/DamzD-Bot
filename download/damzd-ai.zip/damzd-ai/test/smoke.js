// DamzD AI smoke test — fully offline: config values, menu builders, the
// auto-reply timing brain, command gating and the picture loader.
// Run with: npm test
process.env.GROQ_API_KEY = "token-one,token-two,token-one";

const assert = (await import("node:assert")).strict;
const { config } = await import("../config.js");
const { menuText, helpText, connectNote } = await import("../src/menus.js");
const { makeAutoReply } = await import("../src/state.js");
const { createCommands, resolveCommand } = await import("../src/commands.js");
const { botImagePayload, prettyNumber } = await import("../src/utils.js");
const { classifyTask } = await import("../src/ai.js");

let passed = 0;
async function check(label, fn) {
  await fn();
  passed += 1;
  console.log("  ✔ " + label);
}

console.log("DamzD AI smoke test (v" + config.version + ")");

await check("config carries the owner's exact spec values", async () => {
  assert.equal(config.botName, "DamzD AI");
  assert.equal(config.aiName, "DamzD AI");
  assert.equal(config.creatorName, "Great_DamzD");
  assert.equal(config.creatorInfo, "Software developer");
  assert.equal(config.ownerNumber, "2347087299884");
  assert.equal(config.pairNumber, "2347087299884");
  assert.equal(config.prefix, ".");
  assert.equal(config.mode, "public");
  assert.equal(config.version, "1.0.0");
  assert.equal(config.timezone, "Africa/Lagos");
  assert.equal(config.autoReply, true);
  assert.equal(config.autoReplyDelayMs, 300000);
  assert.equal(config.maxHistory, 6);
  assert.equal(config.cooldownSeconds, 5);
  assert.equal(config.reasoningEffort, "high");
  assert.equal(config.botImage, "assets/bot-image.png");
  assert.equal(config.aiSignature, true);
});

await check("Puter tokens parse from GROQ_API_KEY, deduplicated in order", async () => {
  assert.deepEqual(config.puterTokens, ["token-one", "token-two"]);
});

await check("prettyNumber formats the owner number", async () => {
  assert.equal(prettyNumber("2347087299884"), "+234 708 729 9884");
});

await check(".menu opens with the picture and one full info text", async () => {
  const runtime = { mode: "public", autoReply: true, delayMs: () => 300000 };
  const { commands } = createCommands({ config, runtime });
  const action = commands.find(c => c.name === "menu").run({});
  assert.equal(action.image, true, "the picture goes first");
  const menu = action.text;
  assert.equal(typeof menu, "string");
  assert.ok(!menu.includes("\n\n\n"), "no broken spacing — one clean block");
  assert.match(menu, /⚡ DamzD AI ⚡|╭──〔 ⚡ DamzD AI/);
  assert.match(menu, /Great_DamzD/);
  assert.match(menu, /Software developer/);
  assert.match(menu, /\+234 708 729 9884/);
  assert.match(menu, /𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦/);
  assert.match(menu, /5 min/);
  assert.match(menu, /no \. needed/);
});

await check(".help explains the flow and lists every command", async () => {
  const runtime = { mode: "public", autoReply: true, delayMs: () => 300000 };
  const { commands } = createCommands({ config, runtime });
  const help = commands.find(c => c.name === "help").run({}).text;
  for (const word of ["𝗛𝗢𝗪 𝗜 𝗪𝗢𝗥𝗞", "minutes", "𝗡𝗢 𝗗𝗢𝗧 𝗡𝗘𝗘𝗗𝗘𝗗", "menu", "help", "ping", "autoreply", "mode", "setdelay", "reset"]) {
    assert.ok(help.includes(word), "help mentions " + word);
  }
  assert.equal(commands.find(c => c.name === "help").run({}).image, true, "help opens with the picture too");
});

await check("connectNote announces connected-and-online in the menu look", async () => {
  const note = connectNote(config, { number: "2347087299884", autoReply: true });
  assert.match(note, /connected and online ✅/);
  assert.match(note, /1\.0\.0/);
  assert.match(note, /\+2347087299884/);
  assert.match(note, /ON — I step in after 5 min/);
  assert.match(note, /𝗧𝗥𝗬 𝗠𝗘|TRY ME/);
});

await check("auto-reply arms at 5 minutes and answers once", async () => {
  const state = makeAutoReply({ autoReplyDelayMs: 300000, cooldownSeconds: 5, ownerActiveMinutes: 15 });
  const t0 = 1_000_000_000_000;
  assert.equal(state.onIncoming("c1", t0), "armed");
  assert.equal(state.tick("c1", t0 + 299000), false, "4:59 — still waiting");
  assert.equal(state.onIncoming("c1", t0 + 100000), "waiting", "a second message never re-arms");
  assert.equal(state.tick("c1", t0 + 300000), true, "5:00 — the AI steps in");
  assert.equal(state.onIncoming("c1", t0 + 300500), "cooldown", "the 5s cooldown holds right after the AI's first reply");
  assert.equal(state.onIncoming("c1", t0 + 306000), "reply-now", "after the cooldown the live chat answers right away");
  state.noteReply("c1", t0 + 306000); // the bot notes the reply after sending
  assert.equal(state.onIncoming("c1", t0 + 306500), "cooldown", "back-to-back messages stay cooled down");
  assert.equal(state.onIncoming("c1", t0 + 312000), "reply-now", "and the conversation keeps flowing");
  assert.equal(state.tick("c1", t0 + 360000), false, "no second timer once live");
});

await check("the owner's reply stands the AI down, then it rearms", async () => {
  const state = makeAutoReply({ autoReplyDelayMs: 60000, cooldownSeconds: 5, ownerActiveMinutes: 15 });
  const t0 = 2_000_000_000_000;
  state.onIncoming("c2", t0);
  state.tick("c2", t0 + 60000);
  assert.equal(state.onOwnerMessage("c2", t0 + 65000), "stand-down");
  assert.equal(state.onIncoming("c2", t0 + 70000), "idle", "owner present — no timer");
  assert.equal(state.onIncoming("c2", t0 + 910000), "idle", "still inside the 15-minute window (ends t0+965s)");
  assert.equal(state.onIncoming("c2", t0 + 970000), "armed", "window passed — watching again");
});

await check("owner-only commands are gated and work when allowed", async () => {
  const runtime = { mode: "public", autoReply: false, startedAt: Date.now(), delayMs: () => 300000, resetChat: () => {} };
  const { commands, lookup } = createCommands({ config, runtime });
  assert.equal(lookup.get("autoreply").owner, true);
  assert.equal(lookup.get("menu").owner, false);
  const parsed = resolveCommand(".autoreply on", ".", lookup);
  assert.equal(parsed.command.name, "autoreply");
  assert.match(parsed.command.run({ args: "on" }).text, /now \*on\*/);
  assert.match(resolveCommand(".mode private", ".", lookup).command.run({ args: "private" }).text, /only serve Great_DamzD/);
  assert.match(resolveCommand(".setdelay 7", ".", lookup).command.run({ args: "7" }).text, /7 minutes/);
  assert.equal(resolveCommand(".nope", ".", lookup), null, "unknown command rejected");
  assert.equal(resolveCommand("how far", ".", lookup), null, "plain chat never parses as a command");
});

await check("botImagePayload: url passthrough, file buffer, missing file", async () => {
  assert.deepEqual(botImagePayload({ botImage: "https://res.cloudinary.com/x/pic.jpg" }), { image: { url: "https://res.cloudinary.com/x/pic.jpg" } });
  const asFile = botImagePayload({ botImage: "assets/bot-image.png" });
  assert.ok(Buffer.isBuffer(asFile.image), "bundled file becomes a Buffer");
  assert.equal(botImagePayload({ botImage: "assets/missing.png" }), null);
  assert.equal(botImagePayload({ botImage: "" }), null);
});

await check("the task router picks the right Puter brain", async () => {
  assert.equal(classifyTask("fix this javascript bug in my loop"), "code");
  assert.equal(classifyTask("translate good morning to yoruba"), "translate");
  assert.equal(classifyTask("solve 24 x 7 + 12"), "math");
  assert.equal(classifyTask("write me a short poem"), "creative");
  assert.equal(classifyTask("how far, you dey?"), "chat");
});

console.log("\nAll " + passed + " checks passed. DamzD AI is configured, timed and stealthy.");
